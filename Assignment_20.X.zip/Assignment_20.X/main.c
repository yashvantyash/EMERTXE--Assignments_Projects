/*
 * File:   main.c
 * Author: Yashvant B
 *
 * Created on 1 February, 2024, 2:08 PM
 */



 
#include <xc.h>
#include "main.h"
// Funtion call to configure CLCD
static void init_config(void)
{
    init_clcd();
}
static int x = 0;
// Main function
void main(void) {
    char ch;
    init_config();
    // Taking a string
    char str[17] = "Yashvanth       ";
    clcd_print("MY__NAME ", LINE1(4));
    clcd_print(str, LINE2(0));
    
    while (1) 
    {
        // Taking delay
        if (x++ == 3000)
        {
            x = 0;
            ch = str[15];
            int i = 15;
            // Logic for swapping
            while (i != 0) 
            {
                str[i] = str[i - 1];
                i--;
            }
            i = 1;
            str[0] = ch;
            str[16] = '\0';
        }
        // Print the String in CLCD 
        clcd_print(str, LINE2(0));
    }
}
