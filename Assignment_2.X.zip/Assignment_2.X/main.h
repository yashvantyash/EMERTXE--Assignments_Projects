/* 
 * File:   main.h
 * Author: Y @ $ #
 *
 * Created on 9 January, 2024, 6:30 PM
 */



//header file for the function declarations and macro
#include <xc.h>
unsigned char read_dkp(unsigned char);
#define LEVEL 0
#define EDGE 1

