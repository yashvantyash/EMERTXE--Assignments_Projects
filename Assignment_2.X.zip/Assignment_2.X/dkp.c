/*
 * File:   dkp.c
 * Author: Yashwanth B
 *
 * Created on 9 January, 2024, 6:33 PM
 */




#include "main.h"

unsigned char read_dkp(unsigned char detection) {
    static unsigned char once=1;
    if(detection == 0)
    {
        return (PORTC&0X0F);
    }
    else if(detection == 1)
    {
        if(((PORTC&0X0F)!=0X0F) && once )
        {
            once=0;
            return (PORTC&0X0F);
        }
        else if((PORTC&0X0F)==0X0F)
        {
            once=1;
        }
        return 0X0F;
    }
}
