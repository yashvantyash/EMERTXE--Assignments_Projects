/*
 * File:   main.c
 * Author: Yashwanth B
 *
 * Created on 9 January, 2024, 5:32 PM
 */



#include "main.h"

void main(void) {
    //declare the variables
    unsigned int wait = 0;
    //settin the led as input/output
    PORTB = 0X00;
    TRISB = 0X00;
    TRISC = (TRISC | 0X0F);
    signed char i = 1;
    unsigned int f = 1;
    unsigned char once = 1;
    signed char j = 0;
    unsigned int key;
    signed char y = 7;
    signed char t = 8;
    unsigned int count = 0;
    //unsigned char f = 0;
    //for super loop
    while (1) {
        //checking the whether switch is pressed or not
        key = read_dkp(EDGE);
        //condition for the switch 1
        if (key == 0X0E) {
            f = !f;
            //PORTB=0X0F;
        }
        //if the f is 1 we have to run the leds in one direction
        if (f == 1) {
            
            if (wait++ == 50000) {
                //PORTB=0XF0;
                if (count >= 0 && count <= 7) {
                    if (i < 9) {
                        PORTB = (PORTB | (1 << i) - 1);
                        i++;
                        count++;
                        //j=7;
                    }
                } else if (count >= 8 && count <= 15) {
                    if (j < 8) {
                        PORTB = PORTB & (~((1 << j)));
                        j++;
                        count++;
                    }
                } else {
                    count = 0;
                    i = 1;
                    j = 0;
                }
                wait = 0;
            }
            
        }
        //if the f is 0 we have to run them in opposite direction
        if (f == 0) {
           
            if (wait++ == 50000) {
                 //PORTB=0X0F;
                if (count >= 8 && count <= 15) {
                    if ((j+1) >= 0) {
                        PORTB = PORTB | (1 << (j+1));
                        j--;
                        count--;
                    }
                } else if (count >= 0 && count <= 7) {
                    if ((i-1) >= 0) {
                        PORTB = PORTB & (~(1 << (i-1)));
                        i--;
                        count--;
                    }
                } else {
                    count = 15;
                    i = 9;
                    j = 7;
                }
                wait = 0;
                //i=1;
                //wait=0;
            }
        }
    }
}

