/* 
 * File:   main.h
 * Author: Y @ $ #
 * 
 * Created on 23 January, 2024, 2:17 PM
 */
#include <xc.h>
void init_config();
void __interrupt() isr();
void init_timer0();

unsigned char digit[10]={0XE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F};
extern int f=0;
extern int min=0;
extern int hour=0;
extern unsigned int count=0;


