/*
 * File:   config.c
 * Author: Y@$hvant B
 *
 * Created on 23 January, 2024, 2:28 PM
 */




#include "main.h"

void init_config() {
    ADCON1 = 0X0F;
    TRISD = 0X00;
    TRISA = TRISA & 0XF0;  
    PORTA = PORTA & 0XF0;
    // Function Call
    init_timer0();
}
