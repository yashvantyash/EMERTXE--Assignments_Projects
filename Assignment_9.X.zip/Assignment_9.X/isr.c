/*
 * File:   isr.c
 * Author: Yashvant B
 *
 * Created on 23 January, 2024, 2:22 PM
 */




#include "main.h"
void __interrupt() isr()
{
    if(TMR0IF)
    {
        TMR0 = TMR0 + 3038;
        // If '1' min is completed
        if(count++ == (80*60))
        {
            min++;  // Increment the Minute
            count=0;  // Reset the Count
        }
        TMR0IF = 0;
    }
}
