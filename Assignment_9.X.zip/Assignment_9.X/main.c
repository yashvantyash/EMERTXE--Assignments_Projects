/*
 * File:   main.c
 * Author: Y@$hvant B
 *
 * Created on 23 January, 2024, 2:10 PM
 */




#include "main.h"
// Function for displaying 7-segment display (ssD)
void display(char *data)
{
    for (int i = 0; i < 4; i++)
    {
        PORTD = data[i];
        // Configuring PORTA for SSD
        PORTA = (PORTA & 0XF0) | 1 << i;
        for (int i = 0; i < 1000; i++);
    }
}
// Main function
void main()
{
    unsigned char arr[4];
    // Configuring ports
    init_config();
    while (1) 
    {
        // Assign values to display
        arr[0] = digit[hour / 10];
        arr[2] = digit[min / 10];
        arr[3] = digit[min % 10];
        
        // Logic for blinking dot
        if (count / 40 % 2 == 0)
        {
            arr[1] = digit[(hour % 10)] | 0X10 ;
        } 
        else 
        {
            arr[1] = digit[(hour % 10)];
        }
        // If 'min' reaches 60 then make it as 0
        if (min == 60)
        {
            min = 0;
            hour++;
            // If 'hour' reaches 24 then make it as 0
            if (hour == 24) 
            {
                hour = 0;
            }
        }
        display(arr);
    }
}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       


