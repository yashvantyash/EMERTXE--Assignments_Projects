/*
 * File:   ssd_display.c
 * Author: Yashwanth B
 *
 * Created on 9 January, 2024, 2:01 PM
 */



#include "ssd_display.h"
// For SSD configuration
void init_ssd(void) 
{
    TRISD = 0X00;
    TRISA = TRISA & 0XF0;
    PORTA = PORTA & 0XF0;
}

