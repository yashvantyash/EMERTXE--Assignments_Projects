
/* 
 * File:   main.h
 * Author: Y A S H
 * Comments:
 * Revision history: 
 */



#include<xc.h>

void init_config();
void init_ssd();
unsigned char digit[12]={0XE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F,0X40,0X40};

