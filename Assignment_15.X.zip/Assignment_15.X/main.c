/*
 * File:   main.c
 * Author: Yashwanth B
 *
 * Created on 9 January, 2024, 1:52 PM
 */




#include "ssd_display.h"
// Function for display in SSD
void display(char *data) 
{
    for (int i = 0; i < 4; i++) 
    {
        PORTD = data[i];
        PORTA = (PORTA & 0XF0) | 1 << i;
        for(int i=0; i<1000; i++);
    }
}
// Main function
void main(void) 
{
    // Initialization Function
    init_config();
    // Declaration the variables
    unsigned char arr[4];
    unsigned char i = 0;
    unsigned char j = 1;
    unsigned char k = 2;
    unsigned char l = 3;
    unsigned int wait = 0;
    // Super while loop
    while (1)
    {
        // If wait reaches 100 we have to start to increment each one
        if (wait++ == 100) 
        {
            i++;
            j++;
            k++;
            l++;
            if (l == 12) 
            {
                l = 0;
            }
            if (j == 12) 
            {
                j = 0;
            }
            if(k==12)
            {
                k=0;
            }
            if(i==12)
            {
                i=0;
            }


            wait = 0;
        }
        // Dispay it in SSD
        arr[0] = digit[i];
        arr[1] = digit[j];
        arr[2] = digit[k];
        arr[3] = digit[l];
        display(arr);
    }
}
