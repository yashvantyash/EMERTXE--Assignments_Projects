/*
 * File:   init.c
 * Author: Yashwanth B
 *
 * Created on 9 January, 2024, 2:19 PM
 */



#include "ssd_display.h"
// Function for the configuration
void init_config(void)
{
    ADCON1 =0X0F;
    init_ssd();
}

