/*
 * File:   main.c
 * Author: Yashwanth B
 *
 * Created on 4 January, 2024, 2:05 PM
 */


#include <xc.h>
/* Declaration of Delay variable */
unsigned long int delay;

/* Function for Initial configuration */
void init_config()
{
    TRISB=0x00;
}

void main(void)
 {
    init_config();
    int flag=0;
    while(1)
    {
        /* For delay purpose with Non Blocking State */
        if(delay++ == 50000)
        {
            delay=0;
            /* Turn on LED's one by one from left to right */
            if(flag < 8)
            {
                PORTB = PORTB << 1|1;
            }
            /* After all LED's are On, turn it Off in same direction one by one */
            else if(flag < 16)
            {
                PORTB = PORTB << 1;
            }
            /* After all LED's are Off, turn it On LED's one by one from right to left */
            else if(flag < 24)
            {
                PORTB = PORTB >> 1|0x80;
            }
            /* If all LED's are On, turn Off one by one in same direction */
            else if(flag < 32)
            {
                PORTB = PORTB >> 1;
            }
            /* After all LED's are off repeat it from step1 */
            else
            {
                flag=-1;
            }
            /* Increment Flag */
            flag++;
        }
    }
}
