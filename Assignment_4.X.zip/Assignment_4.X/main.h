/* 
 * File:   main.h
 * Author: Y @ $ #
 *
 * Created on 22 January, 2024, 7:40 PM
 */


#include <xc.h>
void init_config();
void __interrupt() isr();
void init_timer0();
void init_timer1();
void init_timer2();

