/*
 * File:   timer.c
 * Author: Y@$hvant B
 *
 * Created on 22 January, 2024, 7:37 PM
 */



#include "main.h"
void init_timer0()
{
    GIE = 1;
    /* Clear old content */
    PEIE = 1;
    /* Enabling Timer0 overflow interrupt */
    TMR0IE = 1;
    /* Clearing Timer0 overflow interrupt flag bit */
    TMR0IF = 0;
    TMR0 = 6;
  //  TMR0ON=1;
 //   T08BIT=1;
    
    /* Selecting internal clock source */
    T0CS = 0;
  //  PSA=1;
}

void init_timer1()
{
    GIE = 1;
    /* Clear old content */
    PEIE = 1;
    /* Enables Timer1 */
    TMR1ON = 1;
    
    /* Enabling Timer1 overflow interrupt */
    TMR1IE = 1;
    
    /* Clearing Timer1 overflow interrupt flag bit */
    TMR1IF = 0;
    TMR1 = 3036;
   /* TMR0ON=1;
    T08BIT=1;
    T0CS=0;
    PSA=1;*/
}

void init_timer2()
{
    GIE = 1;
    /* Clear old content */
    PEIE = 1;
    /* Enabling Timer2 overflow interrupt */
    TMR2IE = 1;
    /* Clearing Timer2 overflow interrupt flag bit */
    TMR2IF = 0;
    /* Enables Timer1 */
    TMR2ON = 1;
    PR2 = 249;
    //TMR0=6;
}
