/*
 * File:   main.c
 * Author: Yashwanth B
 *
 * Created on 22 January, 2024, 7:36 PM
 */



#include "main.h"
void init_config()
{
    /* Config PORTB as digital */
    ADCON1 = 0X0F;
    /* Set PORTB as a Output */
    PORTB = 0X00;
    TRISB = 0X00;
    
/* Initializiation of Timers */
    init_timer0();
    init_timer1();
    init_timer2();
}
void main()
{
    init_config();
    PORTB = 0X00;
    while(1)
    {
        ;
    }
}
