/*
 * File:   interrupt.c
 * Author: Yashwanth B
 *
 * Created on 22 January, 2024, 7:40 PM
 */



unsigned int count=0;
unsigned int count1=0;
unsigned int count2=0;
#include "main.h"
void __interrupt() isr()
{
    if(TMR0IF)
    {
        TMR0 = TMR0 + 8;
        if(count++ == 20000)
        {
            RB0=!RB0;
            count=0;
        }
        TMR0IF=0;
    }
    if(TMR1IF)
    {
        TMR1 = TMR1 + 3038;
        if(count1++ == 80)
        {
            RB1 = !RB1;
            count1 = 0;
        }
        TMR1IF = 0;
    }
    if(TMR2IF)
    {
        if(count2++ == 20000)
        {
            RB2 = !RB2;
            count2 = 0;
        }
        TMR2IF = 0;
    }
}

