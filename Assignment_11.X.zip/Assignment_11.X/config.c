/*
 * File:   config.c
 * Author: Yashvant B
 *
 * Created on 31 January, 2024, 9:19 PM
 */



#include "main.h"

void init_config()
{
    ADCON1 = 0X0F;
    TRISD = 0X00;
    TRISA = TRISA & 0XF0;
    PORTA = PORTA & 0XF0;
    init_timer0();
}
