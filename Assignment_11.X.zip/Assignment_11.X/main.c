/*
 * File:   main.c
 * Author: Yashvanth B
 *
 * Created on 31 January, 2024, 9:16 PM
 */



#include "main.h"
// Function for displaying 7-segment display (ssD)
void display(char *data)
{
    for (int i = 0; i < 4; i++) 
    {
        PORTD = data[i];
        // Configuring PORTA for SSD
        PORTA = (PORTA & 0XF0) | 1 << i;
        for (int i = 0; i < 1000; i++);
    }
}
// Main function
void main() 
{
    // Assigned the variables
    unsigned char arr[4];
    unsigned char key;
    unsigned int t = 0;
    unsigned int e = 0;
    // Configure the ports by function
    init_config();
    //super while loop
    while (1) 
    {
        //checking the key value 
        key = read_dkp(EDGE);
        //if it is read mode then run like clock
        if (t == 0) 
        {
            if (min == 60) 
            {
                min = 0;
                hour++;
                if (hour == 24) 
                {
                    hour = 0;
                }
            }
            arr[0] = digit[hour / 10];
            arr[1] = digit[hour % 10];
            arr[2] = digit[min / 10];
            arr[3] = digit[min % 10];
            // Blinking the dot for every half second
            if (count / 40 % 2 == 0) 
            {
                arr[1] = digit[(hour % 10)] | 0X10;
            } 
            else 
            {
                arr[1] = digit[(hour % 10)];
            }
        }
        // If switch '4' is pressed change the mode
        if (key == 0X07) 
        {
            t = !t;
        } 
        // If switch '1' is pressed Increment 
        else if (key == 0X0E) 
        {
            if (t == 1) 
            {
                // If e is '1' increment hour
                if (e == 1) 
                {
                    hour++;
                    if (hour == 24) 
                    {
                        hour = 0;
                    }
                }
                // If e is '0' increment minute
                else 
                {
                    min++;
                    if (min == 60) 
                    {
                        min = 0;
                    }
                }
            }
        } 
        // If switch 1 is pressed Decrement 
        else if (key == 0X0D) 
        {
            if (t == 1) 
            {
                // If e is 1 decrement hour
                if (e == 1) 
                {
                    hour--;
                    if (hour == -1)
                    {
                        hour = 23;
                    }
                }
                ////if e is 1 decrement minute
                else 
                {
                    min--;
                    if (min == -1) 
                    {
                        min = 59;
                    }
                }
            }
        } 
        // If switch '3' is pressed change the field
        else if (key == 0X0B) 
        {
            e = !e;
        }
        // for 'edit' Mode
        if (t == 1) 
        {
            // If e is o blink minutes
            if (e == 0) 
            {
                if (count / 40 % 2 == 0) 
                {
                    arr[0] = digit[(hour / 10)];
                    arr[1] = digit[(hour % 10)];
                    arr[2] = 0X00;
                    arr[3] = 0X00;
                }
                else 
                {
                    arr[0] = digit[(hour / 10)];
                    arr[1] = digit[(hour % 10)];
                    arr[2] = digit[(min / 10)];
                    arr[3] = digit[(min % 10)];
                }
            } 
            // If e is 1 blink hours
            else 
            {
                if (count / 40 % 2 == 0) 
                {
                    arr[0] = 0X00;
                    arr[1] = 0X00;
                    arr[2] = digit[(min / 10)];
                    arr[3] = digit[(min % 10)];
                } 
                else 
                {
                    arr[0] = digit[(hour / 10)];
                    arr[1] = digit[(hour % 10)];
                    arr[2] = digit[(min / 10)];
                    arr[3] = digit[(min % 10)];
                }
            }
        }
        display(arr);
    }
}

