/*
 * File:   dkp.c
 * Author: Yashvant B
 *
 * Created on 31 January, 2024, 9:19 PM
 */



#include "main.h"
// Function for EDGE or LEVEL TRIGGERING
unsigned char read_dkp(unsigned char detection)
{
    static unsigned char once=1;
    // Condition for LEVEL TRIGGERING
    if(detection == 0)
    {
        return (PORTC&0X0F);
    }
    // Condition for EDGE TRIGGERING
    else if(detection == 1)
    {
        if(((PORTC&0X0F)!=0X0F) && once )
        {
            once=0;
            return (PORTC&0X0F);
        }
        else if((PORTC&0X0F)==0X0F)
        {
            once=1;
        }
        return 0X0F;
    }
}
