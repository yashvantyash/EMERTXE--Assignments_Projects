/* 
 * File:   main.h
 * Author: Y @ $ h
 *
 * Created on 24 November, 2023, 10:34 AM
 */

#include <xc.h>
void init_config();
void __interrupt() isr();
void init_timer0();

unsigned char digit[10]={0XE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F};
extern int f=0;
extern int min=0;
extern int hour=0;
extern unsigned int count=0;
unsigned char read_dkp(unsigned char);
#define LEVEL 0
#define EDGE 1

