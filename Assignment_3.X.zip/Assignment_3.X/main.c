/*
 * File:   main.c
 * Author: Yashwanth B
 *
 * Created on 8 January, 2024, 2:15 PM
 */


#include "main.h"

void main(void) 
{
    // Declaration of variables
    unsigned int wait = 0;
    // Configuring the LED ports as input/output
    PORTB = 0X00;
    TRISB = 0X00;
    TRISC = (TRISC | 0X0F);
    signed char i = 1;
    unsigned int f = 1;
    unsigned char once = 1;
    signed char j = 0;
    unsigned int key;
    signed char y = 7;
    signed char t = 8;
    // Super while loop
    while (1) 
    {
        // We have know whether the key is pressed or not
        key = read_dkp(EDGE);
        // Checking whether the SW1 is pressed or not
        if (key == 0X0E) 
        {
            PORTB = 0X00;
            f = 1;
            i = 1;
            j = 0;
            y = 7;
            t = 8;
            //PORTB=0X0F;
            
        } 
        // Checking whether SW1 is pressed
        else if (key == 0X0D)
        {
            PORTB = 0X00;
            f = 2;
            i = 1;
            j = 0;
            //PORTB=0XF0;
        } 
        // Checking whether SW3 is pressed
        else if (key == 0X0B) 
        {
            PORTB = 0X00;
            f = 3;
            PORTB = 0xaa;
        }
        else if (key == 0x07)
        {
            PORTB = 0X00;
            f = 4;
            PORTB = 0X0F;
        }
        // If f is 1 then it should glow from LEFT to RIGHT and RIGHT to LEFT
        if (f == 1) 
        {
            if (wait++ == 50000) 
            {
                if (i < 9) 
                {
                    PORTB = (PORTB | (1 << i) - 1);
                    i++;
                    //j=7;
                } 
                else if (j < 8) 
                {
                    PORTB = PORTB & (~((1 << j)));
                    j++;

                } 
                else if (y >= 0) 
                {
                    PORTB = PORTB | (1 << y);
                    y--;
                } else if (t >= 0) 
                {
                    PORTB = PORTB & (~(1 << t));
                    t--;
                } else 
                {
                    i = 1;
                    j = 0;
                    y = 7;
                    t = 8;
                }
                wait = 0;
                //i=1;
                //wait=0;
            }
        }
        // If f is 2 then it should glow from LEFT to RIGHT
        else if (f == 2)
        {
            if (wait++ == 50000) 
            {
                if (i < 9) 
                {
                    PORTB = (PORTB | (1 << i) - 1);
                    i++;
                    //j=7;
                } else if (j < 8) 
                {
                    PORTB = PORTB & (~((1 << j)));
                    j++;

                } else 
                {
                    i = 1;
                    j = 0;
                }
                wait = 0;
            }
        }
        // If f is 3 we should BLINK alternately
        else if (f == 3) 
        {
            if (wait++ == 50000) 
            {
             
                PORTB = ~PORTB;
                wait = 0;
                //PORTB = 0XAA;
            }
        } 
        // If f is 4 we should BLINK nibble wise
        else if (f == 4)
        {
            if (wait++ == 50000) 
            {
                PORTB = ~PORTB;
                wait = 0;
            }
        }
    }
    return;

}
