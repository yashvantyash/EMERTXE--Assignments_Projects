/* 
 * File:   main.h
 * Author: Y @ $ #
 *
 * 
 */

// Header file for the function declarations and macro

#include <xc.h>
void init_config();
unsigned char read_dkp(unsigned char);
#define LEVEL 0
#define EDGE 1

