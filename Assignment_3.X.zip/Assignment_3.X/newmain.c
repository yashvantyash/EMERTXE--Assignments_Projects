/*
 * File:   newmain.c
 * Author: Yashwanth B
 *
 * Created on 8 January, 2024, 2:19 PM
 */



#include "main.h"
// Function for know EDGE or LEVEL Triggering
unsigned char read_dkp(unsigned char detection) 
{
    static unsigned char once=1;
    // Condition for LEVEL Triggering
    if(detection == 0)
    {
        return (PORTC & 0X0F);
    }
    // Condition for EDGE Triggering
    else if(detection == 1)
    {
        if(((PORTC & 0X0F) != 0X0F) && once )
        {
            once = 0;
            return (PORTC & 0X0F);
        }
        else if((PORTC & 0X0F)==0X0F)
        {
            once = 1;
        }
        return 0X0F;
    }
}
