#ifndef EX_EEPROM_H
#define EX_EEPROM_H

#define SLAVE_READ		0xA1
#define SLAVE_WRITE		0xA0

//void init_ds1307(void);
void write_ex_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_ex_eeprom(unsigned char address1);

#endif
