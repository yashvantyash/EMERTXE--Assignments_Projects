#ifndef MAIN_H
#define MAIN_H

/* Function declaration */
void store_event(unsigned int count);
void enter_password();
void view_menu();
void change_menu();
void view_log();
void download_log();
void clear_log();
void change_time();
void change_pwd();

#endif
