/*
NAME    : Yashwanth B
DATE    : 06/02/2023
PROJECT : CAR BLACK BOX
*/


#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "adc.h"
#include "matrix_keypad.h"
#include "ex_eeprom.h"
#include "uart.h"

// Initialization of Variables
unsigned char clock_reg[3];
unsigned char time[9];
unsigned short log_flag;
static unsigned short key11_wait_flag;
unsigned short menu_index = 0;
static unsigned short menu_flag;
static unsigned short star_flag;
unsigned char data[10], pre_key;
int node_flag = 0;
unsigned char gear [13][3] = {"ON","GR", "GN", "G1", "G2", "G3", "G4", " C", "VL", "DL", "CL", "ST", "CP"};
int event_index = 0, count;
unsigned short adc_reg_val, res;
unsigned char str[10];
unsigned short count_event_flag;
unsigned int count_event, time1 = 0, count1 = 0;
char original_password[5] = "1100";
char menu[5][17] = {"VIEW LOG        ", "DOWNLOAD LOG    ", "CLEAR LOG       ", "SET TIME        ", "CHANGEPASSWORD"};

/* To display the time in CLCD */
void display_time(void)
{
    clcd_print(time, LINE2(0));
}

/* To read the 24-hour format time from the RTC */
static void get_time(void)
{
    // These lines read the hour, minute, and second registers of the DS1307 RTC module
    // and store the values in the clock_reg array
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);
    
    // To Check whether it is in 12-hour format or 24-hour format 
    if (clock_reg[0] & 0x40)
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    // To extract the hour value from clock_reg[0]
    else
    {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    } 
    // The minutes and seconds values obtained from clock_reg[1] and clock_reg[2]
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}

void init_config(void)
{
    // Function Calls
    init_clcd();
    init_i2c();
    init_ds1307();
    init_matrix_keypad();
    init_adc();
    init_uart();
}

void main(void)
{
    init_config();
    unsigned char key;
    get_time();
    store_event(event_index);

    while (1)
    {
        if(node_flag == 0)
        {
            get_time();
            display_time();
            // reading the analog value from ADC channel 4
            adc_reg_val = read_adc(CHANNEL4);
            // converting the analog value to a corresponding value
            res = (adc_reg_val) / 10.33;
            
            // It displays the tens & units digit of 'res' on the CLCD
            clcd_putch('0' + (res / 10), LINE2(14));
            clcd_putch('0' + (res % 10), LINE2(15));
            clcd_print("  TIME    EV  SP", LINE1(0));
            clcd_print(gear[event_index], LINE2(10));
            // reading the switches to check for any state changes
            key = read_switches(STATE_CHANGE);
            
            // This block handles the increment of the event_index whenever switch-'2' is pressed
            if(key == 2)
            {
                if(event_index < 6)
                    event_index++;
                store_event(event_index);
                // The event_index loops back to 2 when it reaches 7
                if(event_index == 7)
                    event_index = 2;
            }
            // This block handles the decrement of the event_index whenever switch-'3' is pressed
            if(key == 3)
            {
                if(event_index == 7)
                    event_index = 2;
                // The event_index loops back to 2 when it reaches 1
                else if(event_index > 1)
                    event_index--;
                store_event(event_index);

            }
            // When Switch-1 is Pressed Collision happens
            if(key == 1)
            {
                event_index = 7;
                store_event(event_index);
            }
            // When Switch-5 is pressed entering into Password
            if(key == 5)
            {
                CLEAR_DISP_SCREEN;
                node_flag = 1;
            }
        }
        // entering a Password
        else if(node_flag == 1)
        {
            enter_password();
        }
        // View of Menu
        else if(node_flag == 2)
        {
            view_menu();
        }
        // Change Menu settings
        else if(node_flag == 3)
        {
            change_menu();
        }
    }
}

void enter_password()
{
    
    clcd_print(" Enter Password ", LINE1(0));
    static unsigned int k;
    static char read_password[4];
    static unsigned int wait = 0, wait1 = 0;
    unsigned char count = 0;
    static char attempt = 3;
    unsigned char key;
    unsigned int timer = 0;
    
    key = read_switches(STATE_CHANGE);
    
    /* Increment the timer if no key is pressed
    if (key == 0){
        timer++;
    }else {
        // Reset the timer if any key is pressed
        timer = 0;
    }
    
    // Check if the timer reaches 5000 (5 seconds)
    if(timer >= 5000) {
        // Reset timer and return
        return;
    }*/
    
    
 
    
    // To check whether the password entry is not yet complete and if there are still attempts remaining
    if(k < 4 && attempt > 0)
    {
        // blinking cursor effect by alternating between displaying an underscore 
        // and a blank space at the current position on the CLCD
        if(wait++ < 10)
        {
            clcd_putch('_',LINE2(k));
        }
        else if(wait == 20)
        {
            clcd_putch(' ',LINE2(k));
        }
        else
        {
            wait = 0;
        }
        // switch case checks the value of 'key' and assigns the corresponding digit to read_password[k]
        switch(key)
        {
            case 5:
                read_password[k] = '0';
                clcd_putch('*', LINE2(k));
                k++;
                break;
            case 6:
                read_password[k] = '1';
                clcd_putch('*', LINE2(k));
                k++;
                break;
        }
    }
    // Comparing the entered password with original password
    else
    {
        for(k = 0; k < 4; k++)
        {
            if(read_password[k] == original_password[k])
            {
                // increments the count variable for each matching character
                count++;
            }
        }
        // To check whether there are somemore attempts remaining
        if(attempt > 0)
        {
            // If the entered password and Original password matches
            // it prints "SUCCESSFUL" on CLCD
            if(count == 4)
            {
                clcd_print("   SUCCESSFULL  ", LINE2(0));
                CLEAR_DISP_SCREEN;
                node_flag = 2;
            }
            // if the entered password does not match with original password
            else
            {
                // decrements the attempt counter, resets 'k' to 0
                attempt--;
                k = 0;
                CLEAR_DISP_SCREEN;
                // Displays a message indicating the number of attempts left
                clcd_print("   Try Again    ", LINE1(0));
                clcd_putch('0' + attempt, LINE2(0));
                clcd_print("  Attempts Left ", LINE2(1));
                for(wait = 10000;wait--;)
                    for(wait1 = 100;wait1--;);
                clcd_print(" Enter Password ", LINE1(0));
                clcd_print("                ", LINE2(0));
            }
        }
        // This Block for whether there are no attempts remaining
        else
        {
            CLEAR_DISP_SCREEN;
            // Displays a message indicating that attempts are over
            clcd_print(" 3 Attempts Over", LINE1(0));
            clcd_print("Please Wait:     ", LINE2(0));
            // wait for 120 sec
            for(wait = 120; wait--;)
            {
                clcd_putch((wait / 100) + '0', LINE2(13));
                clcd_putch((wait / 10) % 10 + '0', LINE2(14));
                clcd_putch((wait % 10) + '0', LINE2(15));
                for (long i = 500000; i--; );
            }
            CLEAR_DISP_SCREEN;
            attempt = 3;
            k = 0;
        }
    } 
}



void view_menu()
{ 
    // Declaration of variables key and pre_key to store the current and previous switch states
    unsigned char key;
    unsigned char pre_key = key;
    key = read_switches(LEVEL_CHANGE);
    // Print the 'menu' options on lines 1 and 2 of CLCD based on menu_index variable
    clcd_print(menu[menu_index], LINE1(2));
    clcd_print(menu[menu_index + 1], LINE2(2));
    // increments a timer 'time1' and checks if it exceeds a certain threshold limit
    if(key != 0XFF)
    {
        time1++;
        if(time1 > 1500)
        {
            time1 = 0;
            // clears the display and sets node_flag accordingly
            if(key == 5)
            {
                CLEAR_DISP_SCREEN;                                  
                node_flag = 3;
                time1 = 0;
            }
            if(key == 6)
            {
                CLEAR_DISP_SCREEN;
                node_flag = 0;
            }

        }
    }
    // To check if no switch press is detected, but timer 'time1' is still running 
    else if(time1 > 0 && time1 < 1500 )
    {
        time1 = 0;
        // If the previous key press was '6' it either toggles the star_flag 
        // or increments the menu_index to move down the menu
        if(pre_key == 6)
        {
            if(star_flag == 0)
                star_flag = 1;
            else if(menu_index < 3)
            {
                CLEAR_DISP_SCREEN;
                menu_index++;
            }
        }
        // If the previous key press was '5' it either toggles the star_flag 
        // or decrements the menu_index to move up the menu
        if(pre_key == 5)
        {
            if(star_flag == 1)
                star_flag = 0; 
            else if(menu_index > 0)
            {
                CLEAR_DISP_SCREEN;
                menu_index--;
            }
        }
        // Displaying a (*) on the selected menu item if star_flag is set, 
        // indicating that the item is selected
        if(star_flag == 0)
        {
            clcd_putch('*',LINE1(0));
            clcd_putch(' ',LINE2(0));
        }
        else
        {
            clcd_putch(' ',LINE1(0));
            clcd_putch('*',LINE2(0));
        }

    }
    // if neither a switch press is detected nor the timer is running
    else
    {
        time1 = 0;
    }
}
void change_menu()
{
    // calculates an integer log by adding the values of star_flag and menu_index
    // star_flag is typically used to indicate which menu item is currently selected, 
    // menu_index represents the index of the current menu item
    int log = star_flag + menu_index;
    
    // If the calculated value of log is 0, it means the first menu item is selected
    if(log == 0)
    {
        // view_log() function is called to display the Logs
        view_log();
    }
    // If log is 1, it means the second menu item is selected
    else if(log == 1)
    {
        // download_log() function is called to initiate log download
        download_log();
    }
    // If log is 2, it means the third menu item is selected
    else if(log == 2)
    {
        // clear_log() function is called to clear the log
        clear_log();
    }
    // If log is 3, it means the fourth menu item is selected
    else if(log == 3)
    {
        // change_time() function is called to change the time settings
        change_time();
    }
    // If log is 4, it means the fifth menu item is selected
    else if(log == 4)
    {
        // change_pwd() function is called to change the password
        change_pwd(); 
    }
}

void view_log()
{
    clcd_print("LOGs:           ", LINE1(0));
    int num;
    static char index;
    unsigned char key;
    pre_key = key;
    key = read_switches(LEVEL_CHANGE);
    // Check Whether if any switch is pressed 
    if(key != 0XFF)
    {
        // increments the time1 counter 
        time1++;
        // If time1 exceeds 150, it checks if switch 6 is pressed
        if(time1 > 150)
        {
            // it clears the LCD screen and sets node_flag to 2, 
            // indicating that the menu should be shown
            if(key == 6)
            {
                CLEAR_DISP_SCREEN;
                node_flag = 2;
                time1 = 0;
                
            }

        }
    }
    // if no switch is pressed but 'time1' is between 0 and 150
    else if(time1 > 0 && time1 < 150 )
    {
        time1 = 0;
        // checks if the previous key was 6
        if(pre_key == 6)
        {
            // it increments the index if certain conditions are met based on count_event_flag
            if( count_event_flag == 0 && index < count_event-1)
            {
                index++; 
            }
            else if(count_event_flag == 1 && index < 10 )
            {
                index++;
            }
                       
        }
        // if the previous key was 5, it decrements the index if it's greater than 0
        if(pre_key == 5)
        {
            if(index > 0)
            {
                index--;
            }
        }
        
    }
    // Resets 'time1' to 0 if none of the above conditions are met
    else
    {
        time1 = 0;
    }
    // If count_event_flag is 0 
    if(count_event_flag == 0)
    {
        // num is set to 0
        num = 0;
    }
    else
    {
        // otherwise it's set to count_event
        num = count_event;
    }
            // Displaying log information on CLCD
            clcd_putch(index+48,LINE2(0));
            clcd_putch(' ',LINE2(1));
            clcd_putch(read_ex_eeprom(((num + index) % 10) * 10),LINE2(2));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 1),LINE2(3));
            clcd_putch(':',LINE2(4));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 2),LINE2(5));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 3),LINE2(6));
            clcd_putch(':',LINE2(7));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 4),LINE2(8));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 5),LINE2(9));
            clcd_putch(' ',LINE2(10));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 6),LINE2(11));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 7),LINE2(12));
            clcd_putch(' ',LINE2(13));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 8),LINE2(14));
            clcd_putch(read_ex_eeprom((num + index) % 10 * 10 + 9),LINE2(15));
}

void download_log()
{ 
    // get_time() function is called to fetch the current time
    get_time();
    // store_event(9) function is called to store an event with index 9
    store_event(9);
    int num;
    //  If count_event_flag is 0
    if(count_event_flag == 0)
    {
        // it sets num to 0
        num = 0;
    }
    else
    {
        // otherwise, it sets num to count_event
        num = count_event;
    }
    // If count_event_flag is 0 
    if( count_event_flag == 0 )
    {
        // count is set to count_event
        count = count_event;
    }
    // If count_event_flag is 1
    else if(count_event_flag == 1 )
    {
        // count is set to 10
        count = 10;
    }
    
    puts("  TIME    EV   SP\n\r----------------------\n\r\n\r");
    for(int i = 0; i < count; i++)
    {
        putch(i + 48);
        putch(' ');
        putch(read_ex_eeprom((num + i) % 10 * 10 + 0));
        putch(read_ex_eeprom((num + i) % 10 * 10 + 1));
        putch(':');
        putch(read_ex_eeprom((num + i) % 10 * 10 + 2));
        putch(read_ex_eeprom((num + i) % 10 * 10 + 3));
        putch(':');
        putch(read_ex_eeprom((num + i) % 10 * 10 + 4));
        putch(read_ex_eeprom((num + i) % 10 * 10 + 5));
        putch(' ');
        putch(read_ex_eeprom((num + i) % 10 * 10 + 6));
        putch(read_ex_eeprom((num + i) % 10 * 10 + 7));
        putch(' ');
        putch(read_ex_eeprom((num + i) % 10 * 10 + 8));
        putch(read_ex_eeprom((num + i) % 10 * 10 + 9));
        puts("\n\r");
    }
    // Displaying download process is complete
    clcd_print("    DOWNLOAD    ",LINE1(0));
    clcd_print(" LOGs COMPLETED ",LINE2(0));
    for(unsigned int i = 60000;i--;)
        for(unsigned char a = 30; a--;);
    CLEAR_DISP_SCREEN;
    node_flag = 2;
}

void clear_log()
{
    // reset the count_event variable to 0 and set count_event_flag to 0
    count_event = 0;
    count_event_flag = 0;
    // Displaying the log data has been successfully cleared
    clcd_print("  Clear LOGs ", LINE1(0));
    clcd_print(" SUCCESSFULLY", LINE2(0));
    // get_time() function is called to fetch the current time
    get_time();
    // store_event(10) function is called to store an event with index 10
    store_event(10);
    // it creates a delay to wait for a certain amount of time before proceeding
    for(unsigned int i = 60000;i--;)
        for(unsigned char a = 30; a--;);
    CLEAR_DISP_SCREEN;
    node_flag = 2;
}




























































































void change_time()
{
    unsigned char hour = 0,min = 0,sec = 0;
    unsigned static change_flag;
    unsigned char *change_time = time;
    unsigned static int val1 = 0,val2 = 0;
    unsigned char set_time_key = read_switches(LEVEL_CHANGE);
    clcd_print("Time (HH:MM:SEC)",LINE1(0));
    clcd_print(time, LINE2(0));
    // increments val1 or val2 when specific keys are pressed
    if ( set_time_key ==  MK_SW6)
    {
        val1++;
    }
    if ( set_time_key ==  MK_SW5)
    {
        val2++;
    }
    // Checks if val1 is between 1 and 999 and if no key is pressed
    if( val1 < 1000 && val1 > 0 && set_time_key == ALL_RELEASED)
    {
        val1 = 0;
        // it increments change_flag and resets val1

        change_flag++;
        change_flag = change_flag % 3;
    }
    // if val1 is greater than 1000 and no key is pressed, it sets the time based on the entered values
    else if ( val1 > 1000 && set_time_key == ALL_RELEASED )
    {
        // Code to set time
        if ( val1 > 1000)
        {
            // Reset val1 and display success message
            val1 = 0;
            clcd_print("    SET_TIME    ",LINE1(0));
            clcd_print("    SUCCESS     ",LINE2(0));
            val1 = 0;
            // Extract hour, minute, and second from change_time array and write to DS1307 RTC
            hour = (change_time[0] - '0') << 4;
            hour = (change_time[1] - '0' ) | hour;
            write_ds1307(HOUR_ADDR,hour);
            min = (change_time[3] - '0') << 4;
            min = (change_time[4] - '0' ) | min;
            write_ds1307(MIN_ADDR,min);
            sec = (change_time[6] - '0') << 4;
            sec = (change_time[7] - '0' ) | sec;
            write_ds1307(SEC_ADDR,sec);
            // Store event and wait before clearing display
            store_event(11);
            for(unsigned int i = 60000;i--;)
                for (unsigned char j = 20;j--;);
            CLEAR_DISP_SCREEN;
            // Set node_flag to 2
            node_flag = 2;
        }
    }
    // Checks if val2 is between 1 and 999 and if no key is pressed
    if ( val2 < 1000 && val2 > 0 && set_time_key== ALL_RELEASED)
    {
        val2 = 0;
        // Code to increment hours
        if ( change_flag == 0 )
        {
            change_time[1]++;
            if ( change_time[1] > '9' )
            {
                change_time[1] = '0';
                change_time[0]++;
            }
            if( change_time[0] == '2' && change_time[1] == '4')
            {
                change_time[0] = '0';
                change_time[1] = '0';
            }
        }
        // Code to increment minutes
        else if ( change_flag == 1 )
        {
            change_time[4]++;
            if ( change_time[4] > '9' )
            {
                change_time[4] = '0';
                change_time[3]++;
            }
            if( change_time[3] == '6' )
            {
                change_time[3] = '0';
                change_time[4] = '0';
            }

        }
        // Code to increment seconds
        else if ( change_flag == 2 )
        {
            change_time[7]++;
            if ( change_time[7] > '9' )
            {
                change_time[7] = '0';
                change_time[6]++;
            }
            if( change_time[6] == '6')
            {
                change_time[6] = '0';
                change_time[7] = '0';
            }
        }
    }
    // If val2 is greater than 1000 (indicating time incrementing is complete), it resets val2
    else if( val2 > 1000 && set_time_key == ALL_RELEASED)
    {
        val2 = 0;
        for(unsigned int i = 60000;i--;)
            for(unsigned char a = 30; a--;);
        CLEAR_DISP_SCREEN;
        node_flag = 2;
    }
}
void change_pwd()
{
    static unsigned int k;
    static char read_password[4] = {};
    static char confirm_password[4] = {};
    static unsigned int wait = 0, wait1 = 0;
    unsigned char key, count = 0;
    key = read_switches(STATE_CHANGE);

    if(k < 4)
    {
        clcd_print("Enter New Passwd", LINE1(0));
        if(wait++ < 10)
        {
            clcd_putch('_',LINE2(k));
        }
        else if(wait == 20)
        {
            clcd_putch(' ',LINE2(k));
        }
        else
        {
            wait = 0;
        }
        // If the key pressed is 5 or 6, corresponding to '0' or '1', 
        // the entered character is stored in the password array and displayed as '*' on the CLCD
        switch(key)
        {
            case 5:
                read_password[k] = '0';
                clcd_putch('*', LINE2(k));
                k++;
                break;
            case 6:
                read_password[k] = '1';
                clcd_putch('*', LINE2(k));
                k++;
                break;
        }
    }
    else if(k < 8)
    {
        if(k == 4)
            CLEAR_DISP_SCREEN;
        clcd_print("Re-Enter Passwd ", LINE1(0));
        if(wait++ < 10)
        {
            clcd_putch('_',LINE2(k));
        }
        else if(wait == 20)
        {
            clcd_putch(' ',LINE2(k));
        }
        else
        {
            wait = 0;
        }
        // If the key pressed is 5 or 6, corresponding to '0' or '1', 
        // the entered character is stored in the password array and displayed as '*' on the CLCD
        switch(key)
        {
            case 5:
                confirm_password[k-4] = '0';
                clcd_putch('*', LINE2(k));
                k++;
                break;
            case 6:
                confirm_password[k-4] = '1';
                clcd_putch('*', LINE2(k));
                k++;
                break;
        }   
    }
    else if(k == 8)
    {
        k = 0;
        for(k = 0; k < 4; k++)
        {
            if(read_password[k] == confirm_password[k])
            {
                count++;
            }
        }
        
        if(count == 4)
        {
            CLEAR_DISP_SCREEN;
            clcd_print("Change Password ", LINE1(0));
            clcd_print("  Successfully  ", LINE1(0));
            CLEAR_DISP_SCREEN;
            node_flag = 2;
    get_time();
    store_event(12);
    for(unsigned int i = 60000;i--;)
        for(unsigned char a = 30; a--;);
        }
        else
        {
            confirm_password[4];
            read_password[4];
            clcd_print("  Password is   ", LINE1(0));
            clcd_print("  not matched   ", LINE2(0));
            for(unsigned long int j = 500000; j--;);
            CLEAR_DISP_SCREEN;
            node_flag = 2;
        } 
    }
}
/* to store the event on the external EEPROM */
void store_event(unsigned int count)
{
    int i = 0, j = 0;
    // loop iterates through the 'time' array
    while(time[i] != '\0')
    {
        //  To check Whether if the current character in time is not a colon ':'
        if(time[i] != ':')
        {
            // If it's not a colon, it copies the character into the data array and increments j
            data[j++] = time[i];
        }
        i++;
    }
    // Stores gear data from the gear array and result data (res) into the data array
    data[j++] = (char) gear[count][0];
    data[j++] = (char) gear[count][1];
    
    // separate the tens and units digits of the result, 
    // and '0' is added to convert them into ASCII characters before storing in the data array

    data[j++] = (res / 10) + '0'; 
    data[j++] = (res % 10) + '0'; 

    /* To store the data extracted above on the external EEPROM */
    for(j = 0; j < 10; j++)
    {
        write_ex_eeprom((count_event * 10 + j), data[j]);
    }
    /*for(j = 0; j < 10; j++)
      {
      str[j] = read_ex_eeprom(count_event * 10 + j);
      }
      for(j = 0; j < 10; j++)
      {
      clcd_putch(str[j], LINE1(j));
      }*/

    /* If the count of the event is greater than 10; 
     * overwrite the events from the beginning whenever the new event is stored */
    if(count_event < 10)
    {
        count_event++;
    }
    else
    {
        count_event_flag = 1;
        count_event = 0;
    } 
}
  
