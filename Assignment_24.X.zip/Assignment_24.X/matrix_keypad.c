/*
 * File:   matrix_keypad.c
 * Author: Yashvanth B
 *
 * Created on 25 January, 2024, 2:51 PM
 */



#include "main.h"
// Funtion for Matrix_Keypad
unsigned char read_mkp(unsigned char detection) 
{
    static unsigned char once=1;
    static unsigned char key;
    // If it is LEVEL triggering
    if(detection == 0)
    {
      return scan_key();
    }
    // If it is EDGE triggering
    else if(detection == 1)
    {
        key=scan_key();
        if((key!=0XFF) && once )
        {
            once=0;
            return key;
        }
        else if(key==0XFF)
        {
            once=1;
        }
        return 0XFF;
    }
}
