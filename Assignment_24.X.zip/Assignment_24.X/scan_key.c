/*
 * File:   scan_key.c
 * Author: Yashvant B
 *
 * Created on 1 February, 2024, 2:29 PM
 */




#include "main.h"
//checking the key 
unsigned char scan_key()
{
    // Logic for 1st row Keys
    RB5=0;
    RB6=1;
    RB7=1;
    if(RB1==0)
    {
        return 1;
    }
    else if(RB2==0)
    {
        return 4;
    }
    else if(RB3==0)
    {
        return 7;
    }
    else if(RB4==0)
    {
        return 10;
    }
    // Logic for 2nd row Keys
    RB5=1;
    RB6=0;
    RB7=1;
    if(RB1==0)
    {
        return 2;
    }
    else if(RB2==0)
    {
        return 5;
    }
    else if(RB3==0)
    {
        return 8;
    }
    else if(RB4==0)
    {
        return 11;
    }
    // Logic for 3rd row Keys
    RB5=1;
    RB6=1;
    RB7=0;
    //RB7=0;
    if(RB1==0)
    {
        return 3;
    }
    else if(RB2==0)
    {
        return 6;
    }
    else if(RB3==0)
    {
        return 9;
    }
    else if(RB4==0)
    {
        return 12;
    }
    return 0XFF;
}