/*
 * File:   main.c
 * Author: Yashvanth B
 *
 * Created on 25 January, 2024, 2:34 PM
 */




#include "main.h"
// Main function
void main(void) 
{
    init_config();
    unsigned char key;
    clcd_print("ENTER PASSWORD", LINE1(0));
    char str[9] = "09090909";
    
    char s1[17] = "3 ATTEMPTS LEFT";
    //    s1[1]='\0';
    char s2[9] = {};
    int i = 0;
    int count = 0;
    unsigned long int delay = 0;
    unsigned long int delay2 = 0;
    clcd_print("ENTER PASSWORD", LINE1(0));
    clcd_print("_", LINE2(0));
   
    while (1) 
    {
        clcd_print("ENTER PASSWORD", LINE1(0));
        // checking 'i' value for password
        if (i == 8) 
        {
           
            // We have to Compare strings
            if (strcmp(str, s2) == 0) 
            {
                // If they match, displays "SUCCESS"
                clcd_print("SUCCESS", LINE2(0));
                i=8;
            } 
            // If it is not equal we have to display message
            else 
            {
                // Displays "TRY AGAIN" and updates the attempts left message
                clcd_print("TRY AGAIN       ", LINE1(0));
                s1[0] = 51 - (count + 1);
                clcd_print(s1, LINE2(0));
                
                // Introducing a delay and clears the input on the second line of CLCD
                for (delay = 0; delay <= 200000; delay++);
                clcd_print("_               ", LINE2(0));
                i=0;
                // Increment the attempt checks if the maximum attempts (3) have been reached
                count = count + 1;
                // Checking if the maximum attempts(3) have been reached or not
                if (count == 3) 
                {
                    count = 0;
                    clcd_print("TRY AGAIN       ", LINE1(0));
                    clcd_print("FAILURE         ", LINE2(0));
                    i=9;
                }
            }
                
                
        } 
        // Function to read characters of key pressed
        else if (i < 8) 
        {
              if (delay2++ <= 1000)
                    clcd_print("_", LINE2(i));
                else if (delay2 <= 2000) 
                {
                    clcd_print(" ", LINE2(i));
                } 
                else 
                {
                    delay2 = 0;
                }
            key = read_mkp(EDGE);
            // If 'key-1' is pressed store 0
            if (key == 1) 
            {
                s2[i] = '0';
                clcd_print("*", LINE2(i));
                i++;
            } 
            // If 'key-2' is pressed store 9
            else if (key == 2)
            {
                s2[i] = '9';
                clcd_print("*", LINE2(i));
                i++;
            }
        }
    }
}
