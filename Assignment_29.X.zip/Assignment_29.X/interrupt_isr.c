/*
 * File:   interrupt_isr.c
 * Author: Yashwanth B
 *
 * Created on 17 January, 2024, 1:51 PM
 */



#include "main.h"
// Function for Interrupt
void __interrupt() isr() 
{
    // Check if the INT0 interrupt flag is set
    if(INT0IF)
    {
       
       INT0IF = 0;
    }
}

