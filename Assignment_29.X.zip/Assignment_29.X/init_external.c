/*
 * File:   init_external.c
 * Author: Yashwanth B
 *
 * Created on 17 January, 2024, 1:52 PM
 */



#include "main.h"
// Function for setting external Interrupt
void init_external_interrupt() 
{
    GIE = 1;
    PEIE = 1;
    INT0IE = 1;
    INTEDG0 = 1;
    INT0IF = 0;
}


