/*
 * File:   ssd.c
 * Author: Yashwanth B
 *
 * Created on 17 January, 2024, 1:54 PM
 */



#include "main.h"
// Function for configuring the SSD
void init_ssd(void)
{
    // SET all pins of PORT D as Output
    TRISD = 0X00;
    
    // Set the lower 4 bits of port A as output, leaving the upper 4 bits unchanged
    TRISA = TRISA & 0XF0;
    
    // Clear the lower 4 bits of port A, leaving the upper 4 bits unchanged
    PORTA = PORTA & 0XF0;
}