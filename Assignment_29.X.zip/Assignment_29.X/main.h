

/* 
 * File:  main.h 
 * Author: Yashwanth B
 * Comments:
 * Revision history: 
 */


// Header file for Function defnitions and macros
#include <xc.h>

void init_config();
void init_ssd();
void init_external_interrupt();
void __interrupt() isr();
unsigned char digit[12]={0X21,0XCB,0X6B,0X2D};
//unsigned char digit[12]={0XE7,0X21,0XCB,0X6B,0X2D,0X6E,0XEE,0X23,0XEF,0X6F,0X40,0X40};


