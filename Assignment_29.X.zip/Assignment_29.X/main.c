/*
 * File:   main.c
 * Author: B.Yashvant
 *
 * Created on 17 January, 2024, 1:50 PM
 */


#include "main.h"

// Display SSD Function
void display(char *data) 
{
    for (int i = 0; i < 4; i++)
    {
        PORTD = data[i];
        PORTA = (PORTA & 0XF0) | 1 << i;
        for (int i = 0; i < 1000; i++);
    }
}

// Main Function
void main(void) 
{
    init_ssd();
    init_config();
    // Declaration of Variables
    unsigned char key;
    unsigned char arr[4];
    unsigned char i = 0;
    unsigned char j = 1;
    unsigned char k = 2;
    unsigned char l = 3;
    unsigned char count = 0;
    unsigned char wait = 0;
    while (1) 
    {
        if (wait++ == 100)
        {
            PORTB = (PORTB ^ 0X02);
            if(count++ == 5)
            {
                SLEEP();
                count=0;
            }
            
            if (l == 12) 
            {
                l = 0;
            }
            if (j == 12) 
            {
                j = 0;
            }
            if (k == 12)
            {
                k = 0;
            }
            if (i == 12)
            {
                i = 0;
            }
            wait = 0;
        }
        else 
        {
            //wait++;
        }
        arr[0] = digit[i];
        arr[1] = digit[j];
        arr[2] = digit[k];
        arr[3] = digit[l];
        display(arr);
    }

}

