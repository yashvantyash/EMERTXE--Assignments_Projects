/*
 * File:   init_config.c
 * 
 * Author: Yashwanth B
 *
 * Created on 17 January, 2024, 1:53 PM
 */




#include "main.h"
// Function for the Configuration
void init_config()
{
    ADCON1 = 0X0F;
    TRISB = (TRISB | 0X01)& (~2);
    PORTB = PORTB & 0X01;
    init_external_interrupt();
}

