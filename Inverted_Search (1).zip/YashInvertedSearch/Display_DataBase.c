/******************************************

Name: Yashwanth B

Date: 14/12/2023

Description: Display the DataBase

Sample_Input: 2

Sample_Output: ./a.out f1.txt f2.txt

0  an  1  f1.txt  1
0  a  1  f2.txt  1
4  Engineering  1  f1.txt  1
6  Good  1  f2.txt  1
8  is  2  f1.txt  1  f2.txt  1
18  Student  1  f1.txt  1
18  student  1  f2.txt  1
24  Yash  2  f1.txt  1  f2.txt  1
Displayed Successfully

*******************************************/


#include "main.h"

int display(d_node *arr)
{
    // Run the loop for all the index
    for(int i=0; i<27; i++)
    {
	// Checking Whether the link is not null
	if(arr[i].link != NULL)
	{
	    // Creating one main node traverse till NULL
	    m_node *temp = arr[i].link;
	    while(temp != NULL)
	    {
		// Print all the contents in main node

		printf("%d  ",i);
		printf("%s  ",(temp->word));
		printf("%d  ",(temp->f_count));
		
		// Creating one subnode traverse till NULL
		s_node *temp1 = temp->link;
		
		while(temp1 != NULL)
		{
		    // Print all contents in subnode
		    printf("%s  ",(temp1->sname));
		    printf("%d  ",(temp1->w_count));
		    temp1 = temp1->link;
		}
		printf("\n");
		temp = temp->linc;
	    }
	}

    }

    return 1;
}
