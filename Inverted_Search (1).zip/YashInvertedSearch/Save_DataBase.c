/**************************************************

Name : Yashwanth B

Date : 14/12/2023

Description : Save all the contents in one file

Sample_Input : 5

Sample_Output :

Do you want tell the File Name
1.YES
2.NO

Save DataBase is Completed Successfully

***************************************************/






#include "main.h"
// Function definitioin
int save(d_node *arr,char *str)
{
    FILE *f;
    char temp[20] = "Save.txt";
    // Check the str is null and open it in write mode
    if(str == NULL)
    {
	f = fopen(temp,"w");
    }
    else
    {
	f = fopen(str,"w");
    }
    // Run loop fopr all the index
    for(int i=0; i<27; i++)
    {
	// Checking the link is not null
	if(arr[i].link != NULL)
	{
	    // Create the temp varaible and traverse till NULL
	    m_node *temp = arr[i].link;
	    while(temp != NULL)
	    {
		// Transfer all the contents with # to file
		fprintf(f,"#");
		fprintf(f,"%d",i);
		fprintf(f,";");
		fprintf(f,"%s",temp->word);
		fprintf(f,";");
		fprintf(f,"%d",temp->f_count);
		fprintf(f,";");

		s_node *temp1 = temp->link;

		while(temp1 != NULL)
		{
		    fprintf(f,"%s",(temp1->sname));
		    fprintf(f,";");
		    fprintf(f,"%d",(temp1->w_count));
		    fprintf(f,";");
		    temp1 = temp1->link;
		}

		fprintf(f,"#");
		fprintf(f,"\n");
		temp = temp->linc;
	    }
	}
    }

    fclose(f);
    return 1;
}



