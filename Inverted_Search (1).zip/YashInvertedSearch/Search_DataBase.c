/*******************************************
Name : Yashwanth B

Date : 14/12/2023

Description : Search the Word

Sample_Input : 3

Sample_Output : 

Enter the word to Search : is

The 'is' is present in '2' files
f1.txt -> 1 times
f2.txt -> 1 times

*******************************************/


#include "main.h"
int search(d_node *arr,char *str)
{
    // Declaration of Variables
    int i;
    int flag=0;

    // Generate the index
    if(str[0] >= 65 && str[0] <= 90)
    {
	i = str[0] % 65;
    }
    else if(str[0] >= 97 && str[0] <= 122)
    {
	i = str[0] % 97;
    }
    else
    {
	i = 26;
    }
    // Checking the link is not null
    if(arr[i].link != NULL)
    {
	
	m_node *temp = arr[i].link;

	while(temp != NULL)
	{
	    // If the word was found
	    if(strcmp(temp->word,str) == 0)
	    {
               
		printf("The '%s' is present in '%d' files\n",str,temp->f_count);
		s_node *temp1 = temp->link;	

		while(temp1 != NULL)
		{
		  
		    printf("%s -> %d times\n\n",temp1->sname,temp1->w_count);
		    temp1 = temp1->link;
		    flag = 1;
		}
		// The word was found
		if(flag == 1)
		{
		    return 1;
		}
	    }
	    temp = temp->linc;
	}

    }
    return 0;
}


