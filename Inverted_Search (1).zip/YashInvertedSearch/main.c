/*******************************************

Name : Yashwanth B

Date : /12/2023

Description : Inverted Search

Sample_Input : ./a.out f1.txt f2.txt f3.txt

Sample_Output : Search is completed

 ********************************************/


#include "main.h"

int main(int argc,char *argv[])
{
    f_name *head = NULL;
    int flag = 0;
    FILE *fp;
    int opt;
    int op2;
    char str[20];
    int f = 0;
    char ch;
    char s;
    d_node arr[27];
    // Checking the argument count
    if(argc > 1)
    {
	// Run the loop for count
	for(int i=1; i<argc; i++)
	{
	    fp = fopen(argv[i],"r");
	    if(fp != NULL)
	    {
		// Checking whether it is .txt extension or not
		if(strcmp(strstr(argv[i],"."),".txt") == 0)
		{
		    ch = fgetc(fp);
		    // Check whether the EOF or not
		    if(ch != EOF)
		    {
			// Check the head is not null
			if(head != NULL)
			{
			    f_name *temp = head;
			    f_name *prev = NULL;
			    while(temp != NULL)
			    {
				// Compare the filename
				if(strcmp(temp->fname,argv[i]) == 0)
				{
				    printf("%s is a Duplicate\n",argv[i]);
				    flag = 1;
				}
				prev = temp;
				temp = temp->link;
			    }
			    if(flag == 0)
			    {

				f_name *new = malloc(sizeof(f_name));
				if(new == NULL)
				{
				    printf("Node is not created\n");
				}
				else
				{
				    strcpy(new->fname,argv[i]);
				    prev->link = new;
				}
			    }
			}
			else
			{
			    f_name *new = malloc(sizeof(f_name));
			    if(new == NULL)
			    {
				printf("Node is not created\n");
			    }
			    else
			    {
				strcpy(new->fname,argv[1]);
				head = new;
			    }
			}
			rewind(fp);
			fclose(fp);
		    }
		    else
		    {
			printf("%s is Empty\n", argv[i]);
		    }
		}
		else
		{
		    printf("%s is not a '.txt' File\n", argv[i]);
		}
	    }
	    else
	    {
		printf("%s is not Present\n",argv[i]);
	    }
	}
    }

    else
    {
	printf("Error : Please Pass the Command line Arguments\n");
    }

    printf("Read and Validation is Completed\n");
    printf("\n");
    f_name *te = head;

    char option;
    // Run the Super while lopp
    //while(1)
    do
    {

	printf("ENTER THE CHOICE\n1.Create_DataBase\n2.Display_DataBase\n3.Search_DataBase\n4.Update_DataBase\n5.Save_DateBase\n6.Exit\n");
	scanf("%d",&opt);

	switch(opt)
	{
	    case 1:

		if(f == 0)
		{
		    if(create(arr,head) == 1)
		    {
			printf("Database is Created Successfully\n");
		    }
		    else
		    {
			printf("Database is not Created\n");
		    }
		    f=1;
		}
		else
		{
		    printf("Create Database cannot Done due to Update database Done\n");
		}
		break;


	    case 2:

		if(display(arr) == 1)
		{
		    printf("Displayed Successfully\n");
		}
		else
		{
		    printf("Display Function Fail\n");
		}
		break;


	    case 3:


		printf("Enter the Word to Search : ");
		scanf("%s",str);
		if(search(arr,str) == 1)
		{
		    printf("Search DataBase is Completed\n");
		}
		else if(search(arr,str) == 0)
		{
		    printf("Word not Found\n");
		}
		else
		{
		    printf("Search DataBase is Incomplete\n");
		}
		break;


	    case 4:

		if(f == 0)
		{
		    if(update(arr) == 1)
		    {
			printf("Update DataBase is Completed\n");
		    }
		    else
		    {
			printf("Update DataBase is not Completed\n");
		    }

		    f = 1;
		}
		else
		{
		    printf("Create DataBase takes place so cannot Update\n\n");
		}
		break;


	    case 5:

		printf("Do you want tell the File Name\n1.YES\n2.NO\n\n");
		scanf("%d",&op2);
		if(op2 == 1)
		{
		    char str[20];
		    printf("Enter the File Name : ");
		    scanf("%s",str);

		    if(strcmp(strstr(str,"."),".txt") == 0)
		    {
			if(save(arr,str) == 1)
			{
			    printf("Save DataBase is Completed Successfully\n\n");
			}
			else
			{
			    printf("Save DataBase is not Completed\n\n");
			}
		    }
		    else
		    {
			printf("It is not a '.txt' extension\n\n");
		    }
		}
		else
		{
		    //printf("Hello");
		    if(save(arr,NULL) == 1)
		    {
			printf("Save DataBase is Completed Successfully\n\n");
		    }
		    else
		    {
			printf("Save DataBase is not Completed\n\n");
		    }
		}
		break;


	    default:

		exit(0);

	}

	//char option;
	printf("Do you want to continue (y/n): ");

	getchar();
	scanf("%c",&option);
    }
    while(option == 'Y' || option == 'y');
}


