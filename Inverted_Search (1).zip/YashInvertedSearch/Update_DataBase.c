/********************************************

Name : Yashwanth B

Date : /10/2023

Description : Update the DataBase

Sample_Input : 4

Sample_Output : Update is completed

**********************************************/





#include "main.h"
// Function definition
int update(d_node *arr)
{
    // Declare the Datatypes and varaibles
    char fname[50];
    char t[50];
    // Enter the filename
    printf("Enter the File Name : ");
    scanf("%s",t);
    strcpy(fname,t);

    // To check whether the file is '.txt' extension or not
    if((strcmp(strstr(fname,"."),".txt")) != 0)
    {
	printf("Not .txt Extension\n");
	return 0;
    }
    // Creating the hash table
    for(int i=0; i<27; i++)
    {
	arr[i].key = i;
	arr[i].link = NULL;
    }
    //f_name *temp = head;
    // Opening the file
    FILE *f = fopen(fname,"r");
    char str[50];
    char *s;
    char ch;
    int k;
    int a;
    //ch = fgetc(f);
    // Checking the File is there or not
    if(f == NULL)
    {
	printf("File is Empty/File is not Present\n");
	return 0;
    }
    // Skipping one character #
    ch = fgetc(f);
    //printf("file pointer position %ld\n", ftell(f));

    // Run the loop upto eof
    while(fscanf(f,"%s",str) != EOF)
    {
	//printf("str is %s\n", str);
	// Generating the key
	k = atoi(strtok(str,";"));
	printf("%d",k);

	// If the key link is null
	if(arr[k].link == NULL)
	{
	    // Creating one mainnode and subnode 
	    m_node *new = malloc(sizeof(m_node));
	    s_node *n = malloc(sizeof(s_node));

	    // Checking the Node is created or not
	    if(new == NULL || n == NULL)
	    {
		printf("Node is not created\n");
		return 0;
	    }
	    // Using the strtok all the names and count will be assigned
	    strcpy(new->word,strtok(NULL,";"));
	    a=atoi(strtok(NULL,";"))-1;
	    new->f_count = a+1;
	    //printf("file count is %d\n",new->f_count);
	    new->link = n;
	    new->linc = NULL;
	    strcpy(n->sname,strtok(NULL,";"));
	    n->w_count = atoi(strtok(NULL,";"));
	    n->link = NULL;
	    s_node *temp = new->link;
	    // Run the loop for creating subnodes
	    while(a > 0)
	    {
		while( temp->link != NULL)
		    temp = temp->link;
		s_node *p = malloc(sizeof(s_node));
		strcpy(p->sname,strtok(NULL,";"));
		p->w_count = atoi(strtok(NULL,";"));
		p->link = NULL;
		temp->link = p;
		a--;
	    }
	    arr[k].link = new;
	}
	// If the link is not null
	else if (arr[k].link != NULL)
	{
	    m_node *temp1 = arr[k].link;
	    while(temp1->linc != NULL)
	    {
		temp1 = temp1->linc;
	    }
	    m_node *new = malloc(sizeof(m_node));
	    s_node *n = malloc(sizeof(s_node));
	    if(new == NULL || n == NULL)
	    {
		printf("Node is not Created\n");
		return 0;
	    }
	    strcpy(new->word,strtok(NULL,";"));
	    a=atoi(strtok(NULL,";"))-1;
	    new->f_count = a+1;
	    printf("File count is %d\n",new->f_count);
	    new->link = n;
	    new->linc = NULL;
	    strcpy(n->sname,strtok(NULL,";"));
	    n->w_count = atoi(strtok(NULL,";"));
	    n->link = NULL;
	    s_node *temp = new->link;
	    while(a > 0)
	    {
		while( temp->link != NULL)
		    temp = temp->link;
		s_node *p = malloc(sizeof(s_node));
		strcpy(p->sname,strtok(NULL,";"));
		p->w_count = atoi(strtok(NULL,";"));
		p->link = NULL;
		temp->link = p;
		a--;
	    }
	    temp1->linc = new;
	}
	fgetc(f);
	ch = fgetc(f);
	//printf("getc char is %d\n", ch);
    }
    return 1;
}





