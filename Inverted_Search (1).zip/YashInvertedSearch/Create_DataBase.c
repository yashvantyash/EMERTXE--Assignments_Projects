/************************************************

Name : Yashwanth B

Date : 14/12/2023

Description: Creating the DataBase

Sample_Input : 1

Sample_Output : DataBase Created Successfully

 ************************************************/



#include "main.h"

// Function Definition
int create(d_node *arr,f_name *head)
{
    //d_node arr[27];
    // Declaration of Variables
    int k;
    int flag = 0;
    char str[50];

    // Creating the Hashtable
    for(int i=0; i<27; i++)
    {
	arr[i].key = i;
	arr[i].link = NULL;
    }
    //char str[20];

    // Checking Whether head is pointing to NULL or not
    if(head == NULL)
    {
	printf("head is Null\n");
	return 0;
    }
    // If head is not null
    else
    {
	f_name *temp = head;
	FILE *f;
	// Iterates over each file
	while(temp != NULL)
	{
	    // Open the file
	    f=fopen(temp->fname,"r");
	    // Read each word in the file
	    while(fscanf(f,"%s",str)!=EOF)
	    {
		// Generating the key
		if(str[0] >= 65 && str[0] <= 90)
		{
		    k = str[0] % 65;
		}
		else if(str[0] >= 97 && str[0] <= 122)
		{
		    k = str[0] % 97;
		}
		else
		{
		    k = 26;
		}
		// Checking whether the index is null or not
		if(arr[k].link == NULL)
		{
		    // If it is null create mainnode and subnode and assign the values
		    m_node *new = malloc(sizeof(m_node));
		    s_node *n = malloc(sizeof(s_node));
		    // To check whether the node is created or not
		    if(new == NULL || n == NULL)
		    {
			printf("Node is not Created\n");
			return 0;
		    }
		    // Update wordcount,wordname & wordlink
		    new->f_count = 1;
		    strcpy(new->word,str);
		    new->link = n;
		    new->linc = NULL;
		    // Update Values in the subnode
		    n->w_count = 1;
		    strcpy(n->sname,temp->fname);
		    n->link = NULL;
		    arr[k].link = new;
		}
		// If the Index is not Linking to Null
		else
		{
		    m_node *temp1 = arr[k].link;  // Pointer to traverse m_node
		    m_node *prev = NULL;          // Pointer to keep track of the previous m_node
		    int w_flag = 0;               // Flag to check if the word already exists in the m_node
		    int f_flag = 0;               // Flag to check if the file name already exists in the s_node

		    // Traverse till NULL to check whether m_node word matches with input word
		    while(temp1 != NULL)
		    {
			// If the word already exists in the m_node
			if(strcmp(temp1->word,str) == 0)
			{
			    w_flag = 1;
			    s_node *temp_sub = temp1->link;	// Pointer to traverse s_node	
			    s_node *temp_prev = NULL;	        // Pointer to keep track of the previous s_node	

			    // To check if the current s_node's file matches with the input file name
			    while(temp_sub != NULL)
			    {
				// If the File Name Already Exists in the s_node
				if(strcmp(temp_sub->sname,temp->fname)==0)
				{
				    // Increment the word count
				    temp_sub->w_count++;
				    f_flag=1;	// Indicating file was found
				    break;
				}

				temp_prev = temp_sub;
				temp_sub = temp_sub->link;
			    }
			    // If the file name was not found in the s_node
			    if( f_flag == 0 )
			    {
				s_node *new = malloc(sizeof(s_node));
				if( new == NULL )
				{
				    return 0;
				}
				// Update the values and links to the existing list
				new->w_count = 1;
				strcpy(new->sname, temp->fname);
				new -> link = NULL;
				temp_prev -> link = new;
				(temp1->f_count)++;
			    }
			    else
			    {
				f_flag = 0;
			    }
			}
			prev = temp1;
			temp1 = temp1->linc;
		    }
		    // If the word was not found in the m_node
		    if(w_flag == 0)
		    {
			// Create another main and sub node for input word
			m_node *new = malloc(sizeof(m_node));
			s_node *n = malloc(sizeof(s_node));
			// To check whether the node is created or not
			if(new == NULL || n == NULL)
			{
			    printf("Node is not Created\n");
			    return 0;
			}
			// Update the values and links to the existing list
			new->f_count = 1;
			strcpy(new->word,str);
			new->link = n;
			new->linc = NULL;
			prev->linc = new;
			n->w_count = 1;
			strcpy(n->sname,temp->fname);
			n->link = NULL;
		    }
		    else
		    {
			w_flag = 0;
		    }
		}
	    }

	    temp = temp->link;
	}
    }

    return 1;
}
