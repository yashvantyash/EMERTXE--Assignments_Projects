#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct filenode
{
    char fname[50];
    struct filenode *link;
}f_name;



typedef struct subnode
{
    int w_count;
    char sname[50];
    struct subnode *link;
}s_node;



typedef struct mainnode
{
    int f_count;
    char word[50];
    s_node *link;
    struct mainnode *linc;
}m_node;



typedef struct db
{
    int key;
    m_node *link;
}d_node;

/* Create Database */
int create(d_node *arr,f_name *head);

/* Display */
int display(d_node *arr);

/* Search */
int search(d_node *arr,char *str);

/* Save */
int save(d_node *arr,char *str);

/* Update */
int update(d_node *arr);
